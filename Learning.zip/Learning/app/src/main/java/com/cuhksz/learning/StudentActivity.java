package com.cuhksz.learning;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.Image;
import android.os.AsyncTask;
import android.support.annotation.IdRes;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.cert.PolicyNode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class StudentActivity extends AppCompatActivity {

    final static String api_ip = "http://10.23.23.80:8080/";

    Map<Integer,Bitmap> studentPhotos;

    private class Student {
        public String ID;
        public String EName;
        public String CName;
        public String Pinyin;
        public String School;
        public String Major;
        public String SID;
        public String Shape;
        public String Comment;
        public ImageViewMasked imageView;

        Student(String ID, String CName, String EName, String Pinyin,
                String School, String Major, String SID, String Shape, String Comment) {
            this.ID = ID;
            this.CName = CName;
            this.EName = EName;
            this.Pinyin = Pinyin;
            this.School = School;
            this.Major = Major;
            this.SID = SID;
            this.Shape = Shape;
            this.Comment = Comment;
        }


        @Override
        public String toString(){
            return ID + "," + CName + "," + EName +","+ Pinyin +"," +School +","+Major+","+SID +","+Shape+","+Comment;
        }
    }






    List<Student> studentList;

    private class studentAdapter extends ArrayAdapter<Student> {


        public studentAdapter(@NonNull Context context, @LayoutRes int resource, @NonNull List<Student> objects) {
            super(context, resource, objects);
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

            Log.v("cuhksz:getView()", ""+position);

            View view = convertView;
            if (view == null){
                LayoutInflater inflater = (LayoutInflater)
                        StudentActivity.this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

                view = inflater.inflate(R.layout.custom_student_v2, null);
            }

            // Populate view with student info
            // ename
            ((TextView) view.findViewById(R.id.cname)).setText(studentList.get(position).CName);

            // pinyin
            ((TextView) view.findViewById(R.id.pinyin)).setText(studentList.get(position).Pinyin);
            // ename
            ((TextView) view.findViewById(R.id.ename)).setText(studentList.get(position).EName);
            // school/major
//            ((TextView) view.findViewById(R.id.school)).setText(studentList.get(position).School);
//            ((TextView) view.findViewById(R.id.major)).setText(studentList.get(position).Major);
            String study = studentList.get(position).School + "/" + studentList.get(position).Major;
            ((TextView) view.findViewById(R.id.school)).setText(study);

            // comment
            ((TextView) view.findViewById(R.id.comment)).setText(studentList.get(position).Comment);

            // photo
            String sid = studentList.get(position).SID;

            ImageViewMasked v = (ImageViewMasked) view.findViewById(R.id.photo);
            studentList.get(position).imageView = v;
            if (studentPhotos.containsKey(position))
                UpdateStudentPhoto(position, studentPhotos.get(position));
            else
                new DownloadImageTask(position, v).execute(api_ip + "photo?name=" + sid);
            return view;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student);

        studentList = new ArrayList<Student>();
        studentPhotos = new HashMap<>();

        //new DownloadImageTask().execute("http://10.20.15.6:8080/photo?name=114020091.JPG");
        new DownloadJSONTask().execute(api_ip + "student");
}

    private void ConfigureListView() {
        ListView listView = (ListView) findViewById(R.id.listview);

        listView.setAdapter(new studentAdapter(this,-1,studentList));

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(StudentActivity.this, "Successfully selected " + studentList.get(position).CName,
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void ParseStudentJSON(String data) {
        try {

            // Parse the student JSON string
            JSONObject jobj = new JSONObject(data);
            JSONArray students = jobj.getJSONArray("students");

            for(int i=0; i< students.length(); i++) {
                JSONObject student = students.getJSONObject(i);
                String id = student.getString("id");
                String ename = student.getString("ename");
                String cname = student.getString("cname");
                String school = student.getString("school");
                String pinyin = student.getString("pinyin");
                String comment = student.getString("comment");
                String shape = student.getString("shape");
                String major = student.getString("major");
                String sid = student.getString("sid");


                //Append student Object to studentList
                Student s = new Student(id,cname,ename,pinyin,school,major,sid,shape,comment);
                Log.v("cuhk:", s.toString());
                studentList.add(s);
            }


            ConfigureListView();

            Log.i("cuhk:student count", String.valueOf(studentList.size()));

        } catch (Exception ex) {
            Log.e("cuhk:ex", ex.toString());
        }
    }

    private void UpdateStudentPhoto(int position, Bitmap photo)
    {
        ImageViewMasked img = (ImageViewMasked) studentList.get(position).imageView;

        // Get the custom shape
        String shape = "shape_" + studentList.get(position).Shape;
        int drawableID = getResources().getIdentifier(shape, "drawable", getPackageName());

        // Check if a valid shape is returned and is different from current shape

        img.setCurrentBitmap(photo);

        if (studentPhotos.size() >= 20) {
            // todo
        }

        // Update student photo cache
        if (studentPhotos.containsKey(position) == false){
            Bitmap bitmap = Bitmap.createScaledBitmap(photo, img.getWidth(), img.getHeight() ,false);
            studentPhotos.put(position, photo);
        }
    }

    private InputStream OpenHttpConnection(String urlString) throws IOException{

        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
            return conn.getInputStream();
        }
        return null;
    }


    private String getJSON(String url) {
        try {
            InputStream conn = OpenHttpConnection(url);

            BufferedReader in = new BufferedReader(
                    new InputStreamReader(conn));

            String inputLine;
            StringBuilder response = new StringBuilder();
            while ((inputLine = in.readLine()) != null)
                response.append(inputLine);
            in.close();
            return response.toString();

        } catch (Exception ex) {
            Log.e("cuhk:ex", ex.toString());
        }
        return "";
    }

    private Bitmap getBitmap(String url) {
        Bitmap bitmap = null;
        try {
            InputStream conn = OpenHttpConnection(url);
            bitmap = BitmapFactory.decodeStream(conn);
            conn.close();
        } catch (Exception ex) {
            Log.e("cuhk:ex", ex.toString());
        }
        return  bitmap;
    }

    private class DownloadImageTask extends AsyncTask<String, Void, Bitmap> {
        int position;
        View view;

        DownloadImageTask(int position, View view) {
            this.position = position;
            this.view = view;
        }
        protected Bitmap doInBackground(String... urls) {
            return getBitmap(urls[0]);
        }
        protected void onPostExecute(Bitmap result) {
            Log.v("cuhksz:onPostExecute()", ""+position);
            UpdateStudentPhoto(position, result);
        }
    }

    private class DownloadJSONTask extends AsyncTask<String, Void, String> {
        protected String doInBackground(String... urls) {
            return getJSON(urls[0]);
        }
        protected void onPostExecute(String result) {
            Log.v("cuhk:", result);
            ParseStudentJSON(result);
        }
    }

}
