package com.cuhksz.learning;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;

import static android.R.attr.name;

public class MainActivity extends AppCompatActivity {

    private String packageName;
    final static String TAG="cuhk:MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        PackageInfo packageInfo =
                getPackageManager().getPackageArchiveInfo(getPackageResourcePath(),
                        PackageManager.GET_ACTIVITIES);
        packageName = packageInfo.packageName;

        ActivityInfo[] activity = packageInfo.activities;

        ArrayList<String> names = new ArrayList<String>();

        for (ActivityInfo info: packageInfo.activities){
            Log.i(TAG, info.name);
            names.add(info.name);
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                R.layout.spinner_layout, R.id.spinnerTarget, names);

        adapter.setDropDownViewResource(R.layout.spinner_layout);
        Spinner spinner = (Spinner) findViewById(R.id.activity_list);
        spinner.setAdapter(adapter);



    }


    public void onButtonClick(View view){
        Spinner spinner = (Spinner)findViewById(R.id.activity_list);
        String activity = spinner.getSelectedItem().toString();

        // Passing the class name to the selected activity
        Intent intent = new Intent(activity);
        intent.putExtra("title", "this is a little");
//        String[] parts = activity.split("\\.");
//        String title = parts[parts.length-1];
//        intent .putExtra("title", title);

        // Using bundle to pass data
        Bundle bundle = new Bundle();
        bundle.putString("title", "Title from bundle");
        intent.putExtras(bundle);



        //startActivity(intent);
        startActivityForResult(intent,99);
        Toast.makeText(this,"onButtonClick()", Toast.LENGTH_LONG).show();

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 99 && resultCode == RESULT_OK && data != null){
            TextView textview = (TextView) findViewById(R.id.main_title);
            textview.setText(data.getStringExtra("data"));
        }
    }


}
