package com.cuhksz.learning;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class ImageViewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_view);

        new DownloadImageTask().execute("http://10.20.15.6:8080/photo?name=116010274.png");
    }


    private InputStream OpenHttpConnection(String urlString) throws IOException {

        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
            return conn.getInputStream();
        }
        return null;
    }


    private String getJSON(String url) {
        try {
            InputStream conn = OpenHttpConnection(url);

            BufferedReader in = new BufferedReader(
                    new InputStreamReader(conn));

            String inputLine;
            StringBuilder response = new StringBuilder();
            while ((inputLine = in.readLine()) != null)
                response.append(inputLine);
            in.close();
            return response.toString();

        } catch (Exception ex) {
            Log.e("cuhk:ex", ex.toString());
        }
        return "";
    }

    private Bitmap getBitmap(String url) {
        Bitmap bitmap = null;
        try {
            InputStream conn = OpenHttpConnection(url);
            bitmap = BitmapFactory.decodeStream(conn);
            conn.close();
        } catch (Exception ex) {
            Log.e("cuhk:ex", ex.toString());
        }
        return  bitmap;
    }

    private class DownloadImageTask extends AsyncTask<String, Void, Bitmap> {
        protected Bitmap doInBackground(String... urls) {
            return getBitmap(urls[0]);
        }
        protected void onPostExecute(Bitmap result) {
            ImageView img = (ImageView) findViewById(R.id.photo);
            img.setImageBitmap(result);
        }
    }

    private class DownloadJSON extends AsyncTask<String, Void, String> {
        protected String doInBackground(String... urls) {
            return getJSON(urls[0]);
        }
        protected void onPostExecute(String result) {
            Log.v("cuhk:", result);
        }
    }
}
